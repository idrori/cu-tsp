package meshi.energy.beta;

import meshi.energy.AbstractEnergy;
import meshi.energy.EnergyCreator;
import meshi.geometry.DistanceMatrix;
import meshi.molecularElements.Protein;
import meshi.util.CommandList;
import meshi.util.KeyWords;

/**
 * Created by IntelliJ IDEA.
 * User: keasar
 * Date: 18/01/2010
 * Time: 13:51:05
 * To change this template use File | Settings | File Templates.
 */
public class BetaCreator extends EnergyCreator implements KeyWords{
    public BetaCreator() {
        super(BETA);
    }
    public AbstractEnergy createEnergyTerm(Protein protein, DistanceMatrix distanceMatrix, CommandList commands) {
        term = new BetaEnergy(protein, weight);
        return term;
    }
}
