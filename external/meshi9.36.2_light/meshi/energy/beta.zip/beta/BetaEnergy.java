package meshi.energy.beta;

import meshi.energy.AbstractEnergy;
import meshi.energy.TotalEnergy;
import meshi.energy.beta.peptideBonds.PeptideBond;
import meshi.molecularElements.*;
import meshi.molecularElements.Segment;
import meshi.molecularElements.atoms.Atom;

import java.util.ArrayList;

/**
 *
 */
public class BetaEnergy extends AbstractEnergy {
    public static final int NUMBER_OF_DISTANCES = 5;
    public static final double TARGET_DISTANCE = 2.5;
    private ArrayList<BetaEnergyElement> elements ;
    private SegmentList segments;
    private Protein protein;
    public BetaEnergy(Protein protein, double weight) {
        super(toArray(), weight);
        comment = "Beta";
        this.protein = protein;
        PeptideBond.attachPeptideBonds(protein);
        segments = new SegmentList(protein);
        reset();
    }

    public void reset() {
        elements = new ArrayList<BetaEnergyElement>();

        for (Segment segment : segments)
            for (Residue residue : segment)
                elements.add(new BetaEnergyElement(residue, segments, weight));
    }

    public void off() {
        for (BetaEnergyElement element : elements)
            element.off();
    }
    public void on() {
           for (BetaEnergyElement element : elements)
               element.on();
       }

    public double evaluate() {
        double energy = 0;
        for (BetaEnergyElement element : elements)
            energy += element.evaluate();
        return energy;
    }
        public void evaluateAtoms() {
                for (BetaEnergyElement element : elements)
                    element.evaluateAtoms();
            }
        public void test(TotalEnergy energy, Atom atom) {
            for (BetaEnergyElement element : elements)
                element.test(energy, atom);

    }
    public void setNumberOfUpdates(int numberOfUpdates) {
            reset();
            super.setNumberOfUpdates(numberOfUpdates);
    }
}




