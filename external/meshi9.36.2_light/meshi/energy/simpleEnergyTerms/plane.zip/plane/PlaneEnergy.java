/*
 * Copyright (c) 2010. of Chen Keasar, BGU . For free use under LGPL
 */

package meshi.energy.simpleEnergyTerms.plane;

import meshi.energy.EnergyElement;
import meshi.energy.EnergyInfoElement;
import meshi.energy.Parameters;
import meshi.energy.simpleEnergyTerms.SimpleEnergyTerm;
import meshi.geometry.DistanceMatrix;
import meshi.geometry.Torsion;
import meshi.geometry.TorsionList;

/**
 * Plane energy term.
 */
public class PlaneEnergy extends SimpleEnergyTerm {
    protected TorsionList torsionList;
    protected DistanceMatrix distanceMatrix;

    public PlaneEnergy() {
    }

    public PlaneEnergy(TorsionList torsionList, DistanceMatrix distanceMatrix,
                       PlaneParametersList parametersList, EnergyInfoElement info) {
        super(toArray(distanceMatrix, torsionList), parametersList, info);
        this.torsionList = torsionList;
        this.distanceMatrix = distanceMatrix;
        createElementsList(torsionList);
        comment = "Plane";

    }

    public void fixCisTrans() {
        for (Object element : elementsList()){
            ((PlaneEnergyElement)element).fixCisTrans();
        }
    }

    public void scaleWeight(double factor) {
        for (EnergyElement element:elementsList)
            ((PlaneEnergyElement)element).scaleWeight(factor);
    }


    public EnergyElement createElement(Object baseElement, Parameters parameters) {
        return new PlaneEnergyElement(((Torsion) baseElement), parameters, weight);
    }
}    
